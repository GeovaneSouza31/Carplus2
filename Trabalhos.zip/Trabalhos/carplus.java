import java.util.Scanner;

public class CarPlus {

    // --- Cadastro de vendedores ---
    String[] nomesVendedores = new String[30];
    String[] senhasVendedores = new String[30];
    String[] emailsVendedores = new String[30];
    int[] codigosVendedores = new int[30];
    int totalVendedores = 0;

    // --- Cadastro de carros ---
    String[] marcasCarros = new String[100];
    String[] modelosCarros = new String[100];
    int[] anosCarros = new int[100];
    float[] precosCarros = new float[100];
    int totalCarros = 0;

    // --- Dados de login do administrador ---
    String emailAdmin = "admin@carplus.com";
    String senhaAdmin = "CarPlus@2025";

    // Scanner para entrada de dados
    Scanner entrada = new Scanner(System.in);

    // --- Método principal ---
    public static void main(String[] args) {
        CarPlus sistema = new CarPlus();
        sistema.iniciar();
    }

    // --- Fluxo inicial ---
    void iniciar() {
        System.out.println("=====================================");
        System.out.println("         SISTEMA CAR PLUS");
        System.out.println("=====================================");
        if (login()) {
            menuPrincipal();
        } else {
            System.out.println("Acesso negado. Encerrando o sistema...");
        }
    }

    // --- Login do administrador ---
    boolean login() {
        System.out.print("Email: ");
        String email = entrada.nextLine();
        System.out.print("Senha: ");
        String senha = entrada.nextLine();

        if (email.equals(emailAdmin) && senha.equals(senhaAdmin)) {
            System.out.println("\nLogin realizado com sucesso!");
            return true;
        } else {
            System.out.println("\nEmail ou senha incorretos.");
            return false;
        }
    }

    // --- Menu principal ---
    void menuPrincipal() {
        int opcao;
        do {
            System.out.println("\n========== MENU PRINCIPAL ==========");
            System.out.println("1 - Cadastrar Vendedor");
            System.out.println("2 - Cadastrar Carro");
            System.out.println("3 - Comprar Carro");
            System.out.println("4 - Listar Carros");
            System.out.println("5 - Sair");
            System.out.print("Escolha uma opção: ");
            opcao = entrada.nextInt();
            entrada.nextLine(); // limpar buffer

            switch (opcao) {
                case 1:
                    cadastrarVendedor();
                    break;
                case 2:
                    cadastrarCarro();
                    break;
                case 3:
                    comprarCarro();
                    break;
                case 4:
                    listarCarros();
                    break;
                case 5:
                    System.out.println("Saindo do sistema CarPlus...");
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
            }
        } while (opcao != 5);
    }

    // --- Cadastro de vendedor ---
    void cadastrarVendedor() {
        System.out.println("\n--- Cadastro de Vendedor ---");
        System.out.print("Nome: ");
        nomesVendedores[totalVendedores] = entrada.nextLine();
        System.out.print("Email: ");
        emailsVendedores[totalVendedores] = entrada.nextLine();
        System.out.print("Senha: ");
        senhasVendedores[totalVendedores] = entrada.nextLine();
        codigosVendedores[totalVendedores] = totalVendedores + 1;
        totalVendedores++;

        System.out.println("Vendedor cadastrado com sucesso!");
    }

    // --- Cadastro de carro ---
    void cadastrarCarro() {
        System.out.println("\n--- Cadastro de Carro ---");
        System.out.print("Marca: ");
        marcasCarros[totalCarros] = entrada.nextLine();
        System.out.print("Modelo: ");
        modelosCarros[totalCarros] = entrada.nextLine();
        System.out.print("Ano: ");
        anosCarros[totalCarros] = entrada.nextInt();
        System.out.print("Preço: R$ ");
        precosCarros[totalCarros] = entrada.nextFloat();
        entrada.nextLine(); // limpar buffer
        totalCarros++;

        System.out.println("Carro cadastrado com sucesso!");
    }

    // --- Compra de carro ---
    void comprarCarro() {
        if (totalCarros == 0) {
            System.out.println("Nenhum carro disponível para compra.");
            return;
        }

        listarCarros();
        System.out.print("Digite o número do carro que deseja comprar: ");
        int escolha = entrada.nextInt();
        entrada.nextLine();

        if (escolha >= 1 && escolha <= totalCarros) {
            System.out.println("\nVocê comprou o carro: " + modelosCarros[escolha - 1]);
            System.out.println("Valor total: R$ " + precosCarros[escolha - 1]);
        } else {
            System.out.println("Carro inválido.");
        }
    }

    // --- Listar carros cadastrados ---
    void listarCarros() {
        if (totalCarros == 0) {
            System.out.println("Nenhum carro cadastrado ainda.");
            return;
        }

        System.out.println("\n--- LISTA DE CARROS ---");
        for (int i = 0; i < totalCarros; i++) {
            System.out.println((i + 1) + " - " + marcasCarros[i] + " " + modelosCarros[i]
                    + " | Ano: " + anosCarros[i]
                    + " | Preço: R$ " + precosCarros[i]);
        }
    }
}


